.. _11_Interoperabilità_portabilità_dati:

**Interoperabilità e portabilità dei dati**
===========================================

nota interna: valutare se unire col punto precedente ("10 Funzionalità per l’import e l’export dei dati")