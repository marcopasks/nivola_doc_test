.. _Modelli_di_sicurezza:

**Modelli di Sicurezza**
************************

**Nivola** è una piattaforma completamente open source
che semplifica l’utilizzo dei servizi cloud da parte della pubblica amministrazione.
Nivola è realizzata dal **CSI Piemonte** e mette a disposizione potenza di calcolo, storage,
rete e database e molto altro. Il risultato è quello di offrire a ogni amministrazione la completa autonomia nella creazione del proprio sistema informativo e nella migrazione delle applicazioni, in assoluta sicurezza. I servizi sono facilmente scalabili, senza spese di licenza e di gestione dell’hardware.  Ogni ente può quindi creare in autonomia il proprio sistema informativo, pagando esclusivamente in base all’utilizzo, attraverso sistemi di rilevazione dei consumi .
