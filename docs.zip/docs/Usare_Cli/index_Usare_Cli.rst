**Usare la Command Line Interface (CLI)**
=========================================

In questa sezione, sono raccolte le istruzioni per interagire con la piattaforma, 
attraverso la Command Line Interface.

.. toctree::
   :maxdepth: 2
 
   01.1_howto-access-cli.rst
   20.0_howto-cpaas.rst
   30.00_lavorare_con_vm_cli.rst
      30.10_Creare-vm-linux.rst
      30.15_creare-vm-windows.rst
      30.20_spegnere-vm.rst
      30.25_accendere-vm.rst
      30.30_lista_vm.rst
      30.40_lista-dettagli-vm.rst
      30.45_ottenere-pwd.rst
   40.0_howto-secgroupcli.rst
   50.0_howto-use-disk.rst
   60.0_howto-use-ssh.rst
   65.0_Gestione_log.rst
   70.0_Gestione_multiregionCMP.rst
   75.0_Gestione_migrazione.rst
   
   
   
   
   
   