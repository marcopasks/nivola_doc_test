**Come muovere i primi passi**
##############################

In questo capitolo sono descritti
i passaggi fondamentali per iniziare ad utilizzare
la piattaforma.

.. toctree::
   :maxdepth: 2
 
   10_Passaggi_necessari.rst

   
   
   
   
   
   
   